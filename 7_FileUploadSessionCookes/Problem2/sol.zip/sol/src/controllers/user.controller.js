// Please don't change the pre-written code
// Import the necessary modules here
import e from 'express';
import {users, registerUser, authenticateUser} from '../models/user.model.js'
export default class UserController {
  getRegister = (req, res, next) => {
    // Write your code here
    res.render('user-register');

  };
  getLogin = (req, res, next) => {
    // Write your code here
    res.render('user-login');
  };
  addUser = (req, res) => {
    // Write your code here
    registerUser(req.body);
    res.render('user-login');
  };
  loginUser = (req, res) => {
    // Write your code here
    const exist = authenticateUser(req.body);
  if (exist) {
    res.json({ success: true, message: "Login successful" });
  } else {
    res.status(401).json({ success: false, message: "Login failed" });
  }
  };
}
