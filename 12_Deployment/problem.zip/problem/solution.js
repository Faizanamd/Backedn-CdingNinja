export const AWS_LINK = "";
export const PORT = 3000;
